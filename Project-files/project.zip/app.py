import numpy as np
import pickle
import pandas as pd
import os
from flask import Flask, request, render_template

app = Flask(__name__)

# Load trained model
model = pickle.load(open("F:/project/model.pkl", 'rb'))

# Load the list of columns used during training (save this list when training the model in Colab)
trained_columns = pickle.load(open("F:/project/columns.pkl", 'rb'))

@app.route('/')
def home():
    return render_template('Proj1.html')

@app.route('/predict', methods=["POST"])
def predict():
    try:
        # Fetch form inputs
        form_values = request.form.to_dict()

        # Convert numerical values
        numeric_fields = ['temp', 'rain', 'snow', 'year', 'month', 'day', 'hours', 'minutes', 'seconds']
        for field in numeric_fields:
            form_values[field] = float(form_values[field])

        # Create a DataFrame from form input
        df = pd.DataFrame([form_values])

        # One-hot encode 'holiday' and 'weather' to match training format
        df = pd.get_dummies(df)

        # Add missing columns from training set, fill with 0
        for col in trained_columns:
            if col not in df.columns:
                df[col] = 0

        # Ensure columns are in same order
        df = df[trained_columns]

        # Predict traffic volume
        prediction = model.predict(df)

        # Return result
        text = "Estimated Traffic Volume is: " + str(int(prediction[0]))
        return render_template('Proj1.html', prediction_text=text)
    
    except Exception as e:
        return render_template('Proj1.html', prediction_text=f"Error: {e}")

if __name__ == "__main__":
    port = int(os.environ.get('PORT', 5000))
    app.run(port=port, debug=True, use_reloader=False)
